#!/bin/bash
which nginx
result=$?
if [ $result != 0 ];then
	rpm -i ./nginx-1.8.1-1.el6.x86_64.rpm
fi
